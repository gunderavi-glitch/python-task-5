# Problem: Set .discard(), .remove() & .pop()
# https://www.hackerrank.com/challenges/py-set-discard-remove-pop/problem

n = int(input())
s = set(map(int, input().split()))
commands = int(input())

for _ in range(commands):
    parts = input().split()
    command = parts[0]

    if command == "pop":
        if s:
            s.pop()
    elif command == "remove":
        s.remove(int(parts[1]))
    elif command == "discard":
        s.discard(int(parts[1]))

print(sum(s))
