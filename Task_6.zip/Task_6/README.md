# Python Task 06 – HackerRank Coding Practice

Contains 20 individual Python 3 solutions, named `problem1.py` through `problem20.py`.
Each file includes the problem name and HackerRank link in comments.

Run an individual solution with:

```bash
python problem1.py
```

Replace `problem1.py` with the desired file. Each solution is intended to be submitted separately on HackerRank.
